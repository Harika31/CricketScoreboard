package org.example;

import org.example.Service.ReadInputService;

import java.io.File;
import java.io.IOException;

/**
 * Cricket Scorecard app
 * @author: Harika
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    {
        String filePath = new File("inputFile.txt").getAbsolutePath();
        File inputFile = new File(filePath);
        ReadInputService.readInputData(inputFile);
    }
}
