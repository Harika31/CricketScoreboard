package org.example.entity;

public class TeamData
{
    private Integer totalScore = 0;
    private Integer wicketsLost = 0;
    private Double overs = 0.0;
    private Integer noOfWides = 0;
    private Integer noOfNoBalls = 0;

    public TeamData()
    {

    }

    public TeamData(int score, int wickets, Double overs)
    {
        this.totalScore = score;
        this.wicketsLost = wickets;
        this.overs = overs;
    }



    public Integer getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(Integer totalScore) {
        this.totalScore = totalScore;
    }

    public Integer getWicketsLost() {
        return wicketsLost;
    }

    public void setWicketsLost(Integer wicketsLost) {
        this.wicketsLost = wicketsLost;
    }

    public Double getOvers() {
        return overs;
    }

    public void setOvers(Double overs) {
        this.overs = overs;
    }

    public Integer getNoOfWides() {
        return noOfWides;
    }

    public void setNoOfWides(Integer noOfWides) {
        this.noOfWides = noOfWides;
    }

    public Integer getNoOfNoBalls() {
        return noOfNoBalls;
    }

    public void setNoOfNoBalls(Integer noOfNoBalls) {
        this.noOfNoBalls = noOfNoBalls;
    }
}
