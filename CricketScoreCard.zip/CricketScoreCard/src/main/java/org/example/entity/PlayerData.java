package org.example.entity;

public class PlayerData
{
    private Integer index;
    private String name;
    private Integer runs = 0;
    private Boolean isPlayingNow;
    private Boolean isFacingBall;
    private Boolean isOut = false;
    private Integer noOfFours = 0;
    private Integer noOfSixes = 0;
    private Integer ballsFaced = 0;
    //Bowling data variables
//    private Integer noOfBowledBalls = 0;
//    private Integer runsConceded = 0;
//    private Integer wicketsTaken = 0;
//    private Integer noOfMaidenOvers = 0;
//    private Integer noOfDotBalls = 0;

    public PlayerData(String player, Boolean isPlaying, Boolean isFacingBall, Integer index)
    {
        this.index = index;
        this.name = player;
        this.isPlayingNow = isPlaying;
        this.isFacingBall = isFacingBall;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRuns() {
        return runs;
    }

    public void setRuns(Integer runs) {
        this.runs = runs;
    }

    public Boolean getPlayingNow() {
        return isPlayingNow;
    }

    public void setPlayingNow(Boolean playingNow) {
        isPlayingNow = playingNow;
    }

    public Integer getNoOfFours() {
        return noOfFours;
    }

    public void setNoOfFours(Integer noOfFours) {
        this.noOfFours = noOfFours;
    }

    public Integer getNoOfSixes() {
        return noOfSixes;
    }

    public void setNoOfSixes(Integer noOfSixes) {
        this.noOfSixes = noOfSixes;
    }

    public Integer getBallsFaced() {
        return ballsFaced;
    }

    public void setBallsFaced(Integer ballsFaced) {
        this.ballsFaced = ballsFaced;
    }

    public Boolean getFacingBall() {
        return isFacingBall;
    }

    public void setFacingBall(Boolean facingBall) {
        isFacingBall = facingBall;
    }

    public Boolean getIsOut() {
        return isOut;
    }

    public void setIsOut(Boolean out) {
        isOut = out;
    }
}
