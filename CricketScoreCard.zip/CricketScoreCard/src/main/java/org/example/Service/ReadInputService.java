package org.example.Service;

import org.example.entity.PlayerData;
import org.example.entity.TeamData;

import java.io.*;
import java.util.*;

public class ReadInputService
{
    public static void readInputData(File inputFile) throws IOException
    {
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));

        Map<String, PlayerData> teamOnePlayers = new LinkedHashMap<>();
        List<TeamData> teamOneData = new LinkedList<>();

        Map<String, PlayerData> teamTwoPlayers = new LinkedHashMap<>();
        List<TeamData> teamTwoData = new LinkedList<>();

        String inputLine = reader.readLine();
        Integer noOfPlayers = Integer.valueOf(inputLine.split(" ")[inputLine.split(" ").length - 1]);

        inputLine = reader.readLine();
        Integer noOfOvers = Integer.valueOf(inputLine.split(" ")[inputLine.split(" ").length - 1]);
        int count = 0;
        while(count++ < noOfOvers)
        {
            teamOneData.add(new TeamData());
            teamTwoData.add(new TeamData());
        }


        inputLine = reader.readLine();
        inputLine = inputLine.split(" ")[inputLine.split(" ").length - 1];

        count = 0; boolean isTeamOnePlaying = false;
        List<String> players = new ArrayList<>();
        while(count++ < noOfPlayers)
        {
            players.add(reader.readLine());
        }
        switch(inputLine)
        {
            case "1:":
                PlayerDataService.addPlayersInfo(teamOnePlayers, players);
                isTeamOnePlaying = true;
                break;
            case "2:":
                PlayerDataService.addPlayersInfo(teamTwoPlayers, players);
                isTeamOnePlaying = false;
                break;
        }

        count = 0;

        while(count++ < noOfOvers)
        {
            inputLine = reader.readLine();
            inputLine = inputLine.split(" ")[inputLine.split(" ").length - 1];
            inputLine = inputLine.split("")[0];
            int balls = 0, over = Integer.parseInt(inputLine);
            while(balls < 6)
            {
                String run = reader.readLine();
                boolean stopMatch = isTeamOnePlaying ?
                        TeamScoreService.processTheRun(teamOneData, teamOnePlayers, run, over) :
                        TeamScoreService.processTheRun(teamTwoData, teamTwoPlayers, run, over);
                if(stopMatch) break;
                if(!"Wd".equals(run) && !"No".equals(run)) balls++;
            }
            ScorecardService.displayPlayerScorecard(isTeamOnePlaying ? teamOnePlayers : teamTwoPlayers,
                    isTeamOnePlaying ? teamOneData : teamTwoData, isTeamOnePlaying ? "Team 1" : "Team 2");
        }

        inputLine = reader.readLine();
        inputLine = inputLine.split(" ")[inputLine.split(" ").length - 1];
        count = 0; players = new ArrayList<>();
        while(count < noOfPlayers)
        {
            players.add(reader.readLine());
            count++;
        }
        if(isTeamOnePlaying)
            PlayerDataService.addPlayersInfo(teamTwoPlayers, players);
        else
            PlayerDataService.addPlayersInfo(teamOnePlayers, players);

        count = 0;
        while(count++ < noOfOvers)
        {
            inputLine = reader.readLine();
            inputLine = inputLine.split(" ")[inputLine.split(" ").length - 1];
            inputLine = inputLine.split("")[0];
            int balls = 0, over = Integer.parseInt(inputLine);
            while(balls < 6)
            {
                String run = reader.readLine();
                boolean stopMatch = !isTeamOnePlaying ?
                        TeamScoreService.processTheRun(teamOneData, teamOnePlayers, run, over) :
                        TeamScoreService.processTheRun(teamTwoData, teamTwoPlayers, run, over);
                if(stopMatch) break;
                if(!"Wd".equals(run) && !"No".equals(run)) balls++;
            }
            ScorecardService.displayPlayerScorecard(!isTeamOnePlaying ? teamOnePlayers : teamTwoPlayers,
                    !isTeamOnePlaying ? teamOneData : teamTwoData, !isTeamOnePlaying ? "Team 1" : "Team 2");
        }

        ScorecardService.displayTheWinner(teamOneData, teamTwoData);
    }
}
