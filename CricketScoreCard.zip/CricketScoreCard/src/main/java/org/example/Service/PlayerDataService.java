package org.example.Service;

import org.example.entity.PlayerData;

import java.util.List;
import java.util.Map;

public class PlayerDataService
{

    public static void addPlayersInfo(Map<String, PlayerData> team, List<String> playersData)
    {
        int currentPlaying = 0; int index = 1;
        for(String player : playersData)
        {
            team.put(player, new PlayerData(player, currentPlaying < 2 ? true : false,
                    currentPlaying == 0 ? true : false, index++));
            currentPlaying++;
        }

        return;
    }
}
