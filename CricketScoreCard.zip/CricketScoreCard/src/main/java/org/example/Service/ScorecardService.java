package org.example.Service;

import org.example.entity.PlayerData;
import org.example.entity.TeamData;

import java.util.List;
import java.util.Map;

public class ScorecardService
{
    public static void displayPlayerScorecard(Map<String, PlayerData> players, List<TeamData> teamData, String name)
    {
        TeamData data = fetchTeamOverallData(teamData);
        System.out.println("Scorecard for " + name + ":");
        System.out.println("Player Name  Score  4s  6s  Balls");
        for(Map.Entry<String, PlayerData> entry : players.entrySet())
        {
            PlayerData playerData = entry.getValue();
            System.out.println(playerData.getName() + (playerData.getPlayingNow() ? "*" : "") + "           " + playerData.getRuns() + "    " + playerData.getNoOfFours()
            + "    " + playerData.getNoOfSixes() + "    " + playerData.getBallsFaced());
        }
        System.out.println("Runs: " + data.getTotalScore() + "/" + data.getWicketsLost() + "\nOvers: " + data.getOvers());
        System.out.println("-----------------------------");

        return;
    }

    private static TeamData fetchTeamOverallData(List<TeamData> teamData)
    {
        int score = 0, wickets = 0; Double overs = 0.0;
        for(TeamData data : teamData)
        {
            score += data.getTotalScore();
            wickets += data.getWicketsLost();
            overs += data.getOvers();
        }
        return new TeamData(score, wickets, overs);

    }

    public static void displayTheWinner(List<TeamData> teamOneData, List<TeamData> teamTwoData)
    {
        TeamData one = fetchTeamOverallData(teamOneData);
        TeamData two = fetchTeamOverallData(teamTwoData);

        if(one.getTotalScore() != two.getTotalScore())
        {
            String team = one.getTotalScore() > two.getTotalScore() ? "Team 1" : "Team 2";
            int differenceInRuns = Math.abs(one.getTotalScore() - two.getTotalScore());
            System.out.println(team + " won the match by " + differenceInRuns + " runs");
        } else
        {
            System.out.println("Match is a draw");
        }
    }
}
