package org.example.Service;

import org.example.entity.PlayerData;
import org.example.entity.TeamData;

import java.util.List;
import java.util.Map;

public class TeamScoreService
{

    public static boolean processTheRun(List<TeamData> teamData, Map<String, PlayerData> players,
                                        String run, int over)
    {
        PlayerData currentPlayer = fetchCurrentPlayers(players, true);
        switch(run)
        {
            case "W":
            {
                currentPlayer.setBallsFaced(currentPlayer.getBallsFaced() + 1);
                handleWicket(players, currentPlayer, teamData, over);
                break;
            }
            case "Wd":
            {
                handleWideOrNoBall(teamData, over, run);
                break;
            }
            case "No":
            {
                handleWideOrNoBall(teamData, over, run);
                break;
            }
            default:
            {
                int runCnt = Integer.valueOf(run);
                currentPlayer.setBallsFaced(currentPlayer.getBallsFaced() + 1);
                handleRun(players, currentPlayer, teamData, runCnt, over);
                break;
            }

        }
        int totalWickets = 0;
        for(TeamData data : teamData)
            totalWickets += data.getWicketsLost();
        if(totalWickets == players.size() - 1)
            return true;
        return false;
    }

    private static void handleRun(Map<String, PlayerData> players, PlayerData currentPlayer, List<TeamData> teamData, int runCnt, int over)
    {
        TeamData currentData = teamData.get(over - 1);
        currentPlayer.setRuns(currentPlayer.getRuns() + runCnt);
        if(runCnt == 4) {
            currentPlayer.setNoOfFours(currentPlayer.getNoOfFours() + 1);
        }
        else if(runCnt == 6) {
            currentPlayer.setNoOfSixes(currentPlayer.getNoOfSixes() + 1);
        }
        if(runCnt%2 == 1^currentData.getOvers() == 0.5)
        {
            currentPlayer.setFacingBall(false);
            changeFacingStatusOfNewPlayer(players, currentPlayer.getIndex());
        }
        players.put(currentPlayer.getName(), currentPlayer);

        currentData.setTotalScore(currentData.getTotalScore() + runCnt);
        currentData.setOvers(currentData.getOvers() == 0.5 ? 1.0 : currentData.getOvers() + 0.1);

        teamData.set(over - 1, currentData);

        return;
    }

    private static void changeFacingStatusOfNewPlayer(Map<String, PlayerData> players, Integer index)
    {
        for(Map.Entry<String, PlayerData> entry : players.entrySet())
        {
            if(entry.getValue().getPlayingNow() && entry.getValue().getIndex() != index)
            {
                PlayerData nextPlayer = entry.getValue();
                nextPlayer.setFacingBall(true);
                players.put(nextPlayer.getName(), nextPlayer);
                break;
            }
        }
    }


    private static void handleWideOrNoBall(List<TeamData> teamData, int over, String run)
    {
        TeamData currentScore = teamData.get(over - 1);
        currentScore.setTotalScore(currentScore.getTotalScore() + 1);
        if("Wd".equals(run)) currentScore.setNoOfWides(currentScore.getNoOfWides() + 1);
        else if("No".equals(run)) currentScore.setNoOfNoBalls(currentScore.getNoOfNoBalls() + 1);

        teamData.set(over - 1, currentScore);
        return;
    }

    private static void handleWicket(Map<String, PlayerData> players, PlayerData currentPlayer,
                                     List<TeamData> teamData, int over)
    {
        currentPlayer.setPlayingNow(false);
        currentPlayer.setIsOut(true);
        players.put(currentPlayer.getName(), currentPlayer);
        for(Map.Entry<String, PlayerData> entry : players.entrySet())
        {
           if(entry.getValue().getIndex() <= currentPlayer.getIndex() || entry.getValue().getPlayingNow())
               continue;

           PlayerData newPlayer = entry.getValue();
           newPlayer.setPlayingNow(true);
           newPlayer.setFacingBall(true);
           players.put(entry.getKey(), newPlayer);
           break;
        }
        TeamData currentData = teamData.get(over - 1);
        currentData.setWicketsLost(currentData.getWicketsLost() + 1);
        currentData.setOvers(currentData.getOvers() == 0.5 ? 1.0 : currentData.getOvers() + 0.1);
        teamData.set(over - 1, currentData);
        return;
    }

    private static PlayerData fetchCurrentPlayers(Map<String, PlayerData> players, boolean isFacing)
    {
        for(Map.Entry<String, PlayerData> entry : players.entrySet())
        {
            if(isFacing && entry.getValue().getPlayingNow() && entry.getValue().getFacingBall())
            {
                return entry.getValue();
            }
            else if(!isFacing && entry.getValue().getPlayingNow())
                return entry.getValue();
        }
        return null;
    }
}
